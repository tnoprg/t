require("luacom");
print("OK");
