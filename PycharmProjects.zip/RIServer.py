import tornado.ioloop
import tornado.web
import time
import datetime
import numpy as np
import pandas as pd
import threading
import socketserver

ip_port = ("192.168.1.104", 9999)

class MyTCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        try:
            while True:
                self.data=self.request.recv(1024)
                print("{} send:".format(self.client_address),self.data)
                if not self.data:
                    print("connection lost")
                    break
                self.request.sendall(self.data.upper())
        except Exception as e:
            print(self.client_address,"连接断开")
        finally:
            self.request.close()
    def setup(self):
        print("before handle,连接建立：",self.client_address)
    def finish(self):
        print("finish run  after handle")

# the following function will lead a error!!
# [WinError 10053] but the reason is unknown
# class MyServer(socketserver.BaseRequestHandler):
#     def Handle(self):
#         print("OKOKOKOKOKOaaaaaaaaaaaaaaaaaaa")
#         print("conn is :", self.request)  # conn
#         print("addr is :", self.client_address)  # addr
#
#         while True:
#             try:
#                 # 收消息
#                 print("OKOKOKOKOKObbbbbbbbbbbbbbbbb")
#                 data = self.request.recv(1024)
#                 if not data: break
#                 print("收到客户端的消息是", data.decode("utf-8"))
#                 # 发消息
#                 self.request.sendall(data.upper())
#             except Exception as e:
#                 print(e)
#                 break

def threadfunc1():
    s = socketserver.ThreadingTCPServer(ip_port, MyTCPHandler)
    s.serve_forever()

def threadfunc2():
    import socket
    BUFSIZE = 1024  # 收发消息的尺寸
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 买手机
    s.bind(ip_port)  # 手机插卡
    s.listen(5)  # 手机待机

    conn, addr = s.accept()  # 手机接电话
    # print(conn)
    # print(addr)
    print('接到来自%s的电话' % addr[0])

    while True:
        msg = conn.recv(BUFSIZE)  # 听消息,听话
        print(msg, type(msg))

        # conn.send(msg.upper())  # 发消息,说话

    conn.close()  # 挂电话

    s.close()  # 手机关机

df = None

def db_init():
    global df
    df = pd.DataFrame(pd.read_csv('machineinfo.csv'))

def db_update():
    global df
    for index, row in df.iterrows():
        time1 = datetime.datetime.now()
        time2 = datetime.datetime.strptime(row['LastReportTime'], "%Y-%m-%d %H:%M:%S")
        delta = datetime.timedelta(minutes=20)
        if time1- time2 >delta:
            df['IsAlive'][index] = 'NO'
        else:
            df['IsAlive'][index] = 'YES'


def db_setdata(machinename,column,value):
    global df
    for index,row in df.iterrows():
        if row['Machine'] == machinename:
            df.loc[index, column] = value

            break

class MainHandler(tornado.web.RequestHandler):
    global df
    def get(self):
        db_update()
        self.write("Hello, world")
        self.write(str(datetime.datetime.now()))
        self.write('''<table border="1">''')
        self.write('''  <tr>''')
        for cols in df.columns.values:
            self.write('''    <th>'''+cols+'''</th>''')
        self.write('''  </tr>''')
        # ----------------------------------------
        for _, row in df.iterrows():
            self.write('''  <tr>''')
            for cols in df.columns.values:
                self.write('''    <td>'''+str(row[cols])+'''</td>''')
            self.write('''  </tr>''')
        self.write('''</table>''')

def make_app():
    return tornado.web.Application([
        (r"/", MainHandler),
    ])

if __name__ == "__main__":
    t1 = threading.Thread(target=threadfunc1)
    t1.start()



    db_init()

    time1 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    time.sleep(1)
    time2 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    db_setdata('MA2', 'LastReportTime', time1)

    db_setdata('MA5', 'LastReportTime', time2)

    print(df.info())

    df.to_csv('machineinfo.csv',index= None )


    app = make_app()
    app.listen(8888)
    tornado.ioloop.IOLoop.current().start()

#datetime.strptime(str, '%Y-%m-%d')

#datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")